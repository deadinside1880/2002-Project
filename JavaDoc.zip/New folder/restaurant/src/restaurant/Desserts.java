package restaurant;

public class Desserts extends MenuItems{
	public Desserts(String name, String description, double price) {
		super(name, description, price);
		type = itemType.Desserts; 
	}
}